__version__ = "0.1.0"
__title__ = "Bulk Register"
